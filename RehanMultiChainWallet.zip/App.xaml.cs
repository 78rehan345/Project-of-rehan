using System.Windows;

namespace RehanMultiChainWallet
{
    public partial class App : Application
    {
    }
}
