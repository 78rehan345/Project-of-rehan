Rehan MultiChain Wallet - WPF Project

1. Install NuGet Packages:
   - Nethereum.Web3
   - WalletConnectSharp.Desktop (or WalletConnectSharp.Core)
   - TronNet

2. Use Visual Studio to open the project.

3. Files Included:
   - App.xaml
   - App.xaml.cs
   - MainWindow.xaml
   - MainWindow.xaml.cs

4. Sign-in Credentials (for demo):
   Username: rehan2025
   Password: rehan2025

Notes:
- WalletConnect integration is basic; QR code UI and session handling may require enhancement.
- Gas & transaction values should be production-optimized.
